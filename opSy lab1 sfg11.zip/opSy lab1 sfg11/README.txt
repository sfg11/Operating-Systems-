
gcc pre.c -o pre
gcc sort.c -o sort
gcc pipe.c -o pipe
./pipe 
To terminate: Ctrl-D
